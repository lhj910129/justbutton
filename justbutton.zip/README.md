# Justbutton 🟠

"Just a button. For now."  
버튼 하나로 시작하는 스프링부트 + 코틀린 + HTML 프로젝트

## 📦 기술 스택

- Kotlin + Spring Boot
- Gradle
- IntelliJ Community (M1 Mac)
- HTML + fetch API
- Git + GitHub

## ✅ 실행 방법

```bash
./gradlew bootRun
